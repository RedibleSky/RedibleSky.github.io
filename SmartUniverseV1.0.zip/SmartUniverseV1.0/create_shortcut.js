var shortcutName = "SmartUniverse.lnk";
var scriptDir = WScript.ScriptFullName.replace(/[^\\]+$/, "");
var targetPath = scriptDir + "apps\\main.pyw";
var iconPath = scriptDir + "favicon.ico";
var desktopPath = WScript.CreateObject("WScript.Shell").SpecialFolders("Desktop");


function createShortcut() {
    var shell = WScript.CreateObject("WScript.Shell");
    var shortcut = shell.CreateShortcut(desktopPath + "\\" + shortcutName);
    shortcut.TargetPath = "pythonw.exe";
    shortcut.Arguments = targetPath;
    shortcut.WorkingDirectory = scriptDir + "apps";
    shortcut.IconLocation = iconPath;
    shortcut.Save();
}


var fso = new ActiveXObject("Scripting.FileSystemObject");
if (fso.FileExists(iconPath)) {
    createShortcut();
    WScript.Echo("Shortcut created at " + desktopPath + "\\" + shortcutName);
} else {
    WScript.Echo("Icon file not found: " + iconPath);
}

// MADE WITH HELP