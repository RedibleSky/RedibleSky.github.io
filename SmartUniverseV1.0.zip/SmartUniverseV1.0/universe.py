import os
from os import system as command
import subprocess
import sys
import time
import ctypes
from pathlib import Path


script_dir = os.path.dirname(os.path.realpath(__file__))


apps_dir = os.path.dirname(os.path.join(script_dir, 'apps'))
os.chdir(apps_dir)
def install_pip():


    try:
        from PIL import Image
        print("pillow is already installed.")
        
    except ImportError:
        print("One of the python PIPs haven't been installed yet. Here are the required pips that will be installed :")
        print("CustomTkinter, Pillow, Pywin32, PyExecJS")
        print("/!\ Dont worry, we'll only use 'pip install [pip name]' /!\!")
        print("-----------------------------------")

        time.sleep(4)
        print("pillow is not installed. Installing now...")

        subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow"])
        print("pillow has been installed.")

    try:
        from win32com.client import Dispatch
        print("pywin32 is already installed.")
        
    except ImportError:
        print("pywin32 is not installed. Installing now...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pywin32"])
        print("pywin32 has been installed.")

    try:
        from CTkMessagebox import CTkMessagebox
        print("ctkmessagebox is already installed.")
        
    except ImportError:
        print("ctkmessagebox is not installed. Installing now...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "CTkMessagebox"])
        print("ctkmessagebox has been installed.")

    try:
        import execjs
        print("PyExecJS is already installed.")
        
    except ImportError:
        print("PyExecJS is not installed. Installing now...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "PyExecJS"])
        print("PyExecJS has been installed.")
      

    try:
        import customtkinter
        print("customtkinter is already installed.")
        command("pythonw main.pyw")
    except ImportError:
        print("customtkinter is not installed. Installing now...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "customtkinter"])
        print("customtkinter has been installed.")
        command("pythonw main.pyw")
    
    






install_pip()

os.chdir(script_dir)
command("create_shortcut.js")
apps_dir = os.path.join(script_dir, 'apps')
os.chdir(apps_dir)
command("pythonw main.pyw")



