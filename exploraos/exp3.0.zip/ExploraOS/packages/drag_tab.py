import customtkinter as ctk

def make_draggable(frame, topbar):
   
    
 
    frame._drag_data = {'x': 0, 'y': 0}
    
   
    topbar.bind("<ButtonPress-1>", lambda event: on_drag_start(frame, event))
    topbar.bind("<B1-Motion>", lambda event: on_drag_motion(frame, event))
    topbar.bind("<ButtonRelease-1>", lambda event: on_drag_stop(frame, event))

def on_drag_start(frame, event):
   
    frame._drag_data['x'] = event.x
    frame._drag_data['y'] = event.y

def on_drag_motion(frame, event):
   
    delta_x = event.x - frame._drag_data['x']
    delta_y = event.y - frame._drag_data['y']
    
    new_x = frame.winfo_x() + delta_x
    new_y = frame.winfo_y() + delta_y
    
    frame.place(x=new_x, y=new_y) 

def on_drag_stop(frame, event):
    
    frame._drag_data['x'] = 0
    frame._drag_data['y'] = 0
