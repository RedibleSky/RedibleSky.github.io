import tkinter as tk

def animation_color_transation_label(label, start_color, end_color, duration=1000, steps=100):
   
 
    start_rgb = label.winfo_rgb(start_color)
    end_rgb = label.winfo_rgb(end_color)

  
    r_step = (end_rgb[0] - start_rgb[0]) / steps
    g_step = (end_rgb[1] - start_rgb[1]) / steps
    b_step = (end_rgb[2] - start_rgb[2]) / steps

    def update_color(step):
        if step <= steps:
         
            r = int(start_rgb[0] + r_step * step)
            g = int(start_rgb[1] + g_step * step)
            b = int(start_rgb[2] + b_step * step)

            
            color = f"#{r:04x}{g:04x}{b:04x}"


            label.config(fg=color)

            
            label.after(duration // steps, update_color, step + 1)

  
    update_color(0)



def animation_color_transation_frame(frame, start_color, end_color, duration=1000, steps=100):
    start_rgb = frame.winfo_rgb(start_color)
    end_rgb = frame.winfo_rgb(end_color)

    r_step = (end_rgb[0] - start_rgb[0]) / steps
    g_step = (end_rgb[1] - start_rgb[1]) / steps
    b_step = (end_rgb[2] - start_rgb[2]) / steps

    def update_color(step):
        if step <= steps:
            r = int(start_rgb[0] + r_step * step)
            g = int(start_rgb[1] + g_step * step)
            b = int(start_rgb[2] + b_step * step)

            color = f"#{r:04x}{g:04x}{b:04x}"

            frame.config(bg=color)

            frame.after(duration // steps, update_color, step + 1)

    update_color(0)
