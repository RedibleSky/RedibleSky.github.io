import customtkinter as ctk

def resizeEnable(frame):
    frame._drag_data = {'x': 0, 'y': 0}

    resize_handle = ctk.CTkFrame(frame, width=10, height=10, corner_radius=5, bg_color="gray")
    resize_handle.pack(side="bottom", anchor="se", padx=5, pady=5)

    resize_handle.bind("<B1-Motion>", lambda event: resize(frame, event))
    resize_handle.bind("<ButtonRelease-1>", lambda event: stop_resize(frame, event))

def resize(frame, event):

    new_width = frame.winfo_width() + (event.x - frame._drag_data['x'])
    new_height = frame.winfo_height() + (event.y - frame._drag_data['y'])

  
    min_width = 400
    min_height = 100
    max_width = 1900
    max_height = 1450

  
    new_width = max(min_width, min(new_width, max_width))
    new_height = max(min_height, min(new_height, max_height))

   
    frame.configure(width=new_width, height=new_height)


    frame._drag_data['x'] = event.x
    frame._drag_data['y'] = event.y

def stop_resize(frame, event):
    frame._drag_data['x'] = 0
    frame._drag_data['y'] = 0
