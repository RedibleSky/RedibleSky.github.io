import tkinter as tk

def toggle_fullscreen(event=None):
    app.attributes("-fullscreen", not app.attributes("-fullscreen"))
    return "break"

def end_fullscreen(event=None):
    app.attributes("-fullscreen", False)
    return "break"

app = tk.Tk()
app.title("ExploraOS")
app.geometry("820x820")




app.bind("<F11>", toggle_fullscreen)
app.bind("<Escape>", end_fullscreen)

app.mainloop()
