import os
from configparser import ConfigParser

# Function to save username to an ini file
def save_username(username):
    config = ConfigParser()
    config['USER'] = {'username': username}
    with open("config.ini", "w") as configfile:
        config.write(configfile)

# Function to read username from an ini file
def read_username():
    config = ConfigParser()
    if os.path.exists("config.ini"):
        config.read("config.ini")
        return config.get('USER', 'username')
    return None

# Main function
def main():
    saved_username = read_username()
    if saved_username:
        print(f"Welcome back, {saved_username}!")
    else:
        username = input("Enter your username: ")
        save_username(username)
        print(f"Username {username} saved!")

if __name__ == "__main__":
    main()
